
let allSubjects = [];

function updateSubjectDropdown() {
    let subjectDropdown = document.querySelector("#subject");

    subjectDropdown.innerHTML = "";

    allSubjects.forEach((subject) => {
        let option = document.createElement("option");

        option.value = subject.name;
        option.textContent = subject.name;

        subjectDropdown.append(option);
    });
}


let totaltask = 0;
let pendingtask = 0;
let completetask = 0;

function saveSubjects() {
    let userId = localStorage.getItem("currentUserId");
    if (!userId) {
        return
    }

    let user = users.find(ele => ele.id == userId);
    
    if (!user){
        return
    }

    user.subjects = allSubjects

    localStorage.setItem("users", JSON.stringify(users));
}


function loadSubjectsForCurrentUser() {
    let userId = localStorage.getItem("currentUserId");

    let users = JSON.parse(localStorage.getItem("users")) || [];

    let user = users.find(ele => ele.id == userId);

    if (!user) {
        return
    }

    allSubjects = user.subjects || [];

    console.log(user.subjects);
    renderSubjects();
    updateSubjectDropdown();
    renderSubjectChart()
}

window.loadSubjectsForCurrentUser = loadSubjectsForCurrentUser;

const input = document.querySelector("#theme-color");
const hex = document.querySelector("#hex");
const picker = document.querySelector("#picker");

function updateColor() {
    picker.style.backgroundColor = input.value;
    hex.textContent = input.value;
}

input.addEventListener("input", updateColor);
updateColor();

let addSub = document.querySelector(".add-sub-btn");

let overSub = document.querySelector(".overlay-sub-form");

let closeSub = document.querySelector("#sub-close");
let subName = document.querySelector("#subjectName");
let desName = document.querySelector("#description");


addSub.addEventListener("click", () => {


    let changehed = document.querySelector(".flex h3");

    changehed.textContent = "Add New Subject";

    let changep = document.querySelector(".flex p");

    changep.textContent = "Create a new subject to organise your study goals.";

    let adsBtn = document.querySelector(".add-sub");

    adsBtn.textContent = "Add Subject"
    overSub.style.display = "block";
})

closeSub.addEventListener("click", () => {
    overSub.style.display = "none";

    let changehed = document.querySelector(".flex h3");

    changehed.textContent = "Add New Subject";

    let changep = document.querySelector(".flex p");

    changep.textContent = "Create a new subject to organise your study goals.";

    let adsBtn = document.querySelector(".add-sub");

    adsBtn.textContent = "Add Subject"
})

let subForm = document.querySelector(".subject-formtag");

let newSubjects = [];


subForm.addEventListener("submit", (e) => {

    e.preventDefault();
    overSub.style.display = "none";


    let subVal = subName.value.trim();
    let desVal = desName.value.trim();

    if (subVal === "") {
        return;
    }
    console.log(allSubjects);
    let isDuplicate = allSubjects.some((sub) => {
        return sub.id !== editSubject && sub.name.toLowerCase() === subVal.toLowerCase();
    });

    if (isDuplicate) {
        alert("This subject already exists!");
        return;
    }

    if (editSubject !== null) {
        let selectedSub = allSubjects.find((sub) => sub.id == editSubject);

        if (selectedSub) {
            let oldName = selectedSub.name;

            selectedSub.name = subVal;
            selectedSub.color = input.value;
            selectedSub.description = desVal;

            tasks.forEach((task) => {
                if (task.subject === oldName) {
                    task.subject = subVal;
                }
            });

            window.saveTasks();
        }
    }
    else {
        let subjects = {
            id: Date.now(),
            name: subVal,
            color: input.value,
            description: desVal
        };

        allSubjects.push(subjects);
    }

    subForm.reset();
    saveSubjects();
    renderSubjects();
    window.renderSubjectChart();
    updateSubjectDropdown();
    window.dashboardSubjectProgress();
    editSubject = null;
    updateColor();
});

let subjectCards = document.querySelector("#subject-cards")


function renderSubjects() {
    subjectCards.innerHTML = "";

    allSubjects.forEach((subject) => {
        let card = document.createElement("div");
        card.classList.add("subject-card");

        card.style.borderTop = `3px solid ${subject.color}`;

        let taskSub = tasks.filter((check) => check.subject == subject.name);
        let totalTask = taskSub.length;

        let pendSub = tasks.filter((check) => check.subject == subject.name && check.status == "Pending");
        let penTask = pendSub.length;

        let compSub = tasks.filter((check) => check.subject == subject.name && check.status == "Completed");
        let comTask = compSub.length;

        let progress = totalTask === 0 ? 0 : Math.round((comTask / totalTask) * 100);

        let progressSection = document.createElement("div");
        progressSection.classList.add("subject-progress");

        let progressInfo = document.createElement("div");
        progressInfo.classList.add("progress-info");

        let progressLabel = document.createElement("span");
        progressLabel.textContent = "Progress";

        let progressPercent = document.createElement("span");
        progressPercent.textContent = `${progress}%`;

        progressInfo.append(progressLabel, progressPercent);

        let progressTrack = document.createElement("div");
        progressTrack.classList.add("progress-track");

        let progressFill = document.createElement("div");
        progressFill.classList.add("progress-fill");

        progressFill.style.width = `${progress}%`;
        progressFill.style.backgroundColor = subject.color;

        progressTrack.append(progressFill);
        progressSection.append(progressInfo, progressTrack);

        let stats = document.createElement("div");
        stats.classList.add("subject-stats");

        let totalBox = document.createElement("div");
        totalBox.classList.add("stat-box");

        let totalLabel = document.createElement("p");
        totalLabel.textContent = "Total Tasks";

        let totalValue = document.createElement("h3");
        totalValue.textContent = totalTask;

        totalBox.append(totalLabel, totalValue);

        let completedBox = document.createElement("div");
        completedBox.classList.add("stat-box", "completed-box");

        let completedLabel = document.createElement("p");
        completedLabel.textContent = "Completed";

        let completedValue = document.createElement("h3");
        completedValue.textContent = comTask;

        completedBox.append(completedLabel, completedValue);

        let pendingBox = document.createElement("div");
        pendingBox.classList.add("stat-box", "pending-box");

        let pendingLabel = document.createElement("p");
        pendingLabel.textContent = "Pending";

        let pendingValue = document.createElement("h3");
        pendingValue.textContent = penTask;

        pendingBox.append(pendingLabel, pendingValue);

        stats.append(totalBox, completedBox, pendingBox);

        let create = document.createElement("div");
        create.classList.add("flexing");

        let name = document.createElement("h3");
        name.classList.add("dumh3");
        name.textContent = subject.name;

        let icons = document.createElement("div");
        icons.classList.add("icons-flex");

        let editSub = document.createElement("div");
        editSub.classList.add("edit-subject");
        editSub.setAttribute("data-id", subject.id);
        editSub.innerHTML = `<i class="fa-regular fa-pen-to-square"></i>`;

        let delSub = document.createElement("div");
        delSub.classList.add("del-subject");
        delSub.setAttribute("data-id", subject.id);
        delSub.innerHTML = `<i class="fa-solid fa-trash-can"></i>`

        icons.append(editSub, delSub);
        create.append(name, icons);
        card.append(create, progressSection, stats);
        subjectCards.append(card);
    });
    document.querySelector("#dashboard-subject-count").textContent = allSubjects.length;
}

renderSubjects();
updateSubjectDropdown();


console.log(tasks);

function dashboardSubjectProgress() {
    let totalTasks = tasks.length;

    let completedTasks = tasks.filter(task => task.status === "Completed").length;

    let overallProgress = totalTasks === 0 ? 0 : Math.round((completedTasks / totalTasks) * 100);

    let donutSelect = document.querySelector(".donut-center h2");
    donutSelect = `${overallProgress}%`;

    let subjectList = document.querySelector(".subject-list");
    subjectList.innerHTML = "";

    allSubjects.forEach(subject => {

        let subjectTasks = tasks.filter(task => task.subject === subject.name);

        let total = subjectTasks.length;

        let completed = subjectTasks.filter(task => task.status === "Completed").length;

        let progress = total === 0 ? 0 : Math.round((completed / total) * 100);

        let row = document.createElement("div");
        row.classList.add("subject-row");

        let dot = document.createElement("span");
        dot.classList.add("dot");
        dot.style.backgroundColor = subject.color;

        let name = document.createElement("span");
        name.classList.add("subject-name");
        name.textContent = subject.name;

        let track = document.createElement("div");
        track.classList.add("mini-track");

        let fill = document.createElement("div");
        fill.classList.add("mini-fill");
        fill.style.width = `${progress}%`;
        fill.style.backgroundColor = subject.color;

        track.append(fill);

        let percent = document.createElement("span");
        percent.classList.add("percent");
        percent.textContent = `${progress}%`;

        row.append(dot, name, track, percent);
        subjectList.append(row);


    });

}

dashboardSubjectProgress();

window.renderSubjects = renderSubjects;

let editSubject = null;

subjectCards.addEventListener("click", (e) => {
    let eIcon = e.target.closest(".edit-subject");
    let dIcon = e.target.closest(".del-subject");

    if (eIcon) {
        overSub.style.display = "block";

        let changehed = document.querySelector(".flex h3");

        changehed.textContent = "Edit Subject";

        let changep = document.querySelector(".flex p");

        changep.textContent = "Edit your subject";

        let adsBtn = document.querySelector(".add-sub");

        adsBtn.textContent = "Edit Subject"

        let subEId = eIcon.getAttribute("data-id");
        let selectedSub = allSubjects.find((sub) => sub.id == subEId);

        subName.value = selectedSub.name;
        editSubject = selectedSub.id;
        desName.value = selectedSub.description;
        input.value = selectedSub.color;
        updateColor();
    }

    if (dIcon) {
        let subDId = dIcon.getAttribute("data-id");

        if (confirm("Are you sure you want to delete this subject?")) {
            allSubjects = allSubjects.filter((sub) => sub.id != subDId);

            saveSubjects();
            renderSubjects();
            updateSubjectDropdown();
        }
    }
});



let subjectChart;

function renderSubjectChart() {

    let canvas = document.querySelector("#subjectProgressChart");

    if (!canvas) {
        return;
    }

    if (typeof Chart === "undefined") {
        return;
    }


    let subjectProgress = allSubjects.map(subject => {
        let subjectTasks = tasks.filter(task => task.subject === subject.name);

        let total = subjectTasks.length;

        let completed = subjectTasks.filter(task => task.status === "Completed").length;
        return {
            name: subject.name,
            color: subject.color,
            total: total,
            completed: completed
        };
    })

    let filteredSubs = subjectProgress;

    let chartData = {
        labels: filteredSubs.map(subject => {
            return `${subject.name} (${subject.total})`
        }),

        datasets: [{
            data: filteredSubs.map(subject => {
                return subject.total
            }),

            backgroundColor: filteredSubs.map(subject => {
                return subject.color || "pink"
            }),

            borderColor: "#151020",
            // borderWidth: 3,
            hoverOffset: 50
            // spacing: 3
        }]
    };

    if (subjectChart) {
        subjectChart.data = chartData;
        subjectChart.update();
        return;
    }

    subjectChart = new Chart(canvas, {
        type: "doughnut",
        data: chartData,

        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: "0%",

            plugins: {
                legend: {
                    position: "bottom",

                    labels: {
                        color: "#E9D5FF",
                        usePointStyle: true
                    }
                },

                tooltip: {
                    callbacks: {
                        label(context) {
                            let subject = filteredSubs[context.dataIndex];

                            if (!subject) {
                                return
                            }
                            return `${subject.name}: ${subject.completed}/${subject.total} tasks completed`;
                        }
                    }
                }
            }
        }
    });
}


window.renderSubjectChart = renderSubjectChart;
renderSubjectChart();












