users = JSON.parse(localStorage.getItem("users")) || [];
let tasks = [];
let editTask = null;
let search = "";


let addBtn = document.querySelector(".add-new-task");
let addClose = document.querySelector(".add-new-task1");
let taskbox = document.querySelector(".add-task-box");

let taskForm = document.querySelector(".task-form");

let overlayTask = document.querySelector(".overlay-taskform")


addBtn.addEventListener("click", () => {
    taskForm.reset();
    overlayTask.style.display = "block";
    taskbox.style.display = "block";
})


let closebtn = document.querySelector(".taskform-close");

let totalCount = document.querySelector(".total-count");
let pendingCount = document.querySelector(".pending-count");
let completedCount = document.querySelector(".completed-count");

closebtn.addEventListener("click", () => {
    let saveBtn = document.querySelector(".add-new-task1");
    saveBtn.textContent = "Add Task"
    let formhead = document.querySelector(".dum2 h3")
    let cleardown = document.querySelector(".dum2 p")
    cleardown.textContent = "Fill in the details to create a new task"
    formhead.textContent = "Add New Task"

    overlayTask.style.display = "none";
    taskbox.style.display = "none";
})

let taskName = document.querySelector("#taskname");
let subject = document.querySelector("#subject");
let priority = document.querySelector("#priority");
let dueDate = document.querySelector("#duedate");
let taskContainer = document.querySelector(".all-task-data");


let flatpickrInstance = flatpickr(dueDate, {
    minDate: "today",
    defaultDate: new Date(),
    dateFormat: "Y-m-d"
});


function saveTasks() {
    let userId = localStorage.getItem("currentUserId");
    console.log(userId);
    if (!userId){
        return
    }

    let latestUsers = JSON.parse(localStorage.getItem("users")) || [];
    let user = latestUsers.find(ele => ele.id == userId);

    if (!user) {
        return;
    }

    user.tasks = tasks;

    localStorage.setItem("users", JSON.stringify(latestUsers));

    users = latestUsers;

}

window.saveTasks = saveTasks;

function loadTasksForCurrentUser() {
    let userId = localStorage.getItem("currentUserId");
    console.log(userId);
    if (!userId){
        return
    }

    let latestUsers = JSON.parse(localStorage.getItem("users")) || [];
    let user = latestUsers.find(ele => ele.id == userId);

    if (!user) {
        return;
    }
    users = latestUsers;
    tasks = user.tasks || [];

    taskContainer.innerHTML = "";
    renderTaskStatus();
    updateTaskCounts();
    dashboardCount();
}


window.loadTasksForCurrentUser = loadTasksForCurrentUser;


function updateTaskCounts() {
    let total = tasks.length;
    let completed = tasks.filter(task => task.status == "Completed").length;
    let pending = tasks.filter(task => task.status == "Pending").length;

    totalCount.textContent = total;
    completedCount.textContent = completed;
    pendingCount.textContent = pending;

    document.querySelector("#dashboard-tasks-completed").textContent = `${completed} / ${total}`;

    localStorage.setItem("Total", total);
    localStorage.setItem("Pending", pending);
    localStorage.setItem("completed", completed);
}

updateTaskCounts();

function dashboardCount() {
    let dashPending = tasks.filter(task => task.status == "Pending")

    let sortingTasks = dashPending.sort((a, b) => new Date(a.date) - new Date(b.date)).slice(0, 4);

    let upcomingContainer = document.querySelector("#dashboard-upcoming-tasks");
    upcomingContainer.innerHTML = "";

    sortingTasks.forEach(task => {
        let taskRow = document.createElement("div");
        taskRow.classList.add("task-row");

        let empty = document.createElement("div");
        empty.classList.add("emptytask");

        let taskLabel = document.createElement("p");
        taskLabel.textContent = task.name;

        let dateText = document.createElement("p");
        dateText.classList.add("task-date");
        dateText.textContent = new Date(task.date).toLocaleDateString();

        empty.append(taskLabel, dateText);

        let subRow = document.createElement("div");
        subRow.classList.add("subrow");

        let subText = document.createElement("p");
        subText.classList.add("subtext");
        subText.textContent = task.subject;

        subRow.append(subText);

        let prior = document.createElement("div");
        prior.classList.add("priordiv");

        let priorsetting = document.createElement("p");
        priorsetting.classList.add("pro");

        priorsetting.textContent = task.priority;

        prior.append(priorsetting);
        
        taskRow.append(empty,subRow,prior);
        upcomingContainer.appendChild(taskRow);
    });
}


function renderTasks(task) {
    let taskRow = document.createElement("div");
    taskRow.classList.add("each-task-row");

    taskRow.dataset.id = task.id;

    let taskInfo = document.createElement("div");
    taskInfo.classList.add("dum5");

    let taskTitle = document.createElement("p");
    taskTitle.setAttribute("title", "task-name")
    taskTitle.classList.add("taskName-in-list");
    taskTitle.textContent = task.name;

    let taskSubject = document.createElement("p");
    taskSubject.setAttribute("title", "subject")
    taskSubject.classList.add("subject-in-list");
    taskSubject.textContent = task.subject;

    taskInfo.append(taskTitle, taskSubject);

    let dateDiv = document.createElement("div");
    dateDiv.classList.add("date-icon");

    let calendarIcon = document.createElement("i");
    calendarIcon.classList.add("fa-regular", "fa-calendar");

    let dateText = document.createElement("span");
    dateText.setAttribute("title", "Due Date")
    dateText.classList.add("duedate-in-list");

    let formattedDate = new Date(task.date).toLocaleDateString();

    dateText.textContent = formattedDate;
    dateDiv.append(calendarIcon, dateText);

    let priorityDiv = document.createElement("div");
    priorityDiv.classList.add("prior");

    let priorityText = document.createElement("p");
    priorityText.setAttribute("title", "Priority");
    priorityText.classList.add("priorname", `priority-${task.priority}`);
    priorityText.textContent = task.priority.charAt(0).toUpperCase() + task.priority.slice(1);


    priorityDiv.appendChild(priorityText);

    let actions = document.createElement("div");
    actions.classList.add("edit-delete-div");

    let editDiv = document.createElement("div");
    editDiv.classList.add("edit-icon");
    editDiv.setAttribute("title", "Edit Button")
    if (task.status === "Completed") {
        editDiv.style.cursor = "not-allowed";
    }
    editDiv.innerHTML = '<i class="fa-solid fa-pen"></i>';

    let deleteDiv = document.createElement("div");
    deleteDiv.classList.add("delete-icon");
    deleteDiv.setAttribute("title", "Delete Button")
    deleteDiv.innerHTML = '<i class="fa-solid fa-trash-can"></i>';


    let statusBtn = document.createElement("div");
    statusBtn.classList.add("task-status-btn");
    statusBtn.setAttribute("title", "Mark as Complete")
    statusBtn.innerHTML = `<i class="fa-regular fa-square-check"></i>`;

    if (task.status == "Completed") {
        statusBtn.classList.add("completed");
    }
    else {
        statusBtn.classList.remove("completed")
    }


    statusBtn.dataset.id = task.id;

    actions.append(statusBtn, editDiv, deleteDiv);
    taskRow.append(taskInfo, dateDiv, priorityDiv, actions);

    taskContainer.append(taskRow);
}

let totalTasks = 0;
let pendingTasks = 0;



function addTask() {

    if (!dueDate.value.trim()) {
        alert("Please select a due date");
        return;
    }

    let taskDict = {}

    let taskValue = taskName.value.trim();
    let subjectValue = subject.value;
    let dateValue = dueDate.value;
    let priorityValue = priority.value;

    taskDict.id = Date.now();
    taskDict.name = taskValue;
    taskDict.subject = subjectValue;
    taskDict.date = dateValue;
    taskDict.priority = priorityValue;
    taskDict.status = "Pending";

    totalTasks += 1;
    pendingTasks += 1;

    pendingCount.textContent = pendingTasks;
    totalCount.textContent = totalTasks;

    tasks.unshift(taskDict);
    saveTasks();
    dashboardCount();
    renderTaskStatus();
    console.log(localStorage.getItem("studyTasks"));
    updateTaskCounts();
    window.renderSubjects();
    window.renderSubjectChart();
    window.dashboardSubjectProgress();

}

function editingTask() {
    if (!dueDate.value) {
        alert("Please select a due date");
        return;
    }
    let taskRow = editTask;
    let taskId = +(taskRow.dataset.id);

    let selectedTask = tasks.find(task => task.id == taskId);

    let taskValue = taskName.value.trim();
    let subjectValue = subject.value;
    let dateValue = dueDate.value;
    let priorityValue = priority.value;
    if (selectedTask.status != "Completed") {
        selectedTask.name = taskValue;
        selectedTask.subject = subjectValue;
        selectedTask.date = dateValue;
        selectedTask.priority = priorityValue;

        saveTasks()
        renderTaskStatus();
        updateTaskCounts();
        dashboardCount();
        console.log("Task edited")
        window.renderSubjects();

    }
}

taskForm.addEventListener("submit", function (event) {
    event.preventDefault();

    let nameValue = taskName.value.trim();
    let dateValue = dueDate.value.trim();        

    if (nameValue == "" || dateValue == "" || priority.value.trim() == ""){
        console.log("Validation failed");
        alert("Every field is mandatory")
        return 
    }

    console.log("Form submitted");
    if (editTask == null) {
        addTask();
    }  
    else {  
        editingTask();
        editTask = null;
    }

    let saveBtn = document.querySelector(".add-new-task1");
    saveBtn.textContent = "Add Task"
    let formhead = document.querySelector(".dum2 h3")
    let cleardown = document.querySelector(".dum2 p")
    cleardown.textContent = "Fill in the details to create a new task"
    formhead.textContent = "Add New Task"
    flatpickrInstance.setDate(new Date());

    console.log("Closing form");
    overlayTask.style.display = "none";
    taskbox.style.display = "none";
});

taskContainer.addEventListener("click", function (event) {
    let deleteButton = event.target.closest(".delete-icon");

    if (deleteButton) {
        let confirmation = confirm("Do you really want to delete this task?")
        if (confirmation) {
            let taskRow = deleteButton.closest(".each-task-row");
            let taskId = +(taskRow.dataset.id);

            tasks = tasks.filter(task => task.id !== taskId);

            saveTasks();
            taskRow.remove();
            updateTaskCounts();
            window.renderSubjects();
        }
    }

    let editIcon = event.target.closest(".edit-icon");
    let editTaskBtn = document.querySelector(".add-new-task");
    let saveBtn = document.querySelector(".add-new-task1");

    if (editIcon) {
        let formhead = document.querySelector(".dum2 h3")
        let cleardown = document.querySelector(".dum2 p")
        cleardown.textContent = "Edit your existing task"
        formhead.textContent = "Edit Task"
        saveBtn.textContent = "+ Save Changes";
        editTask = editIcon.closest(".each-task-row");
        console.log("edit task", editTask);

        let taskNameLst = editTask.querySelector(".taskName-in-list")
        let subNameLst = editTask.querySelector(".subject-in-list")
        let dateLst = editTask.querySelector(".duedate-in-list");
        let prior = editTask.querySelector(".priorname");

        let taskRow = editTask;
        let taskId = +(taskRow.dataset.id);

        let selectedTask = tasks.find(task => task.id == taskId);
        if (selectedTask.status != "Completed") {
            overlayTask.style.display = "block";
            taskbox.style.display = "block";
        }

        let fillName = taskNameLst.textContent;
        let fillSub = subNameLst.textContent;
        let fillDate = dateLst.textContent;
        let fillPrior = prior.textContent;

        taskName.value = fillName.trim();
        subject.value = fillSub.trim();
        flatpickrInstance.setDate(selectedTask.date, false, "Y-m-d");
        priority.value = fillPrior.toLowerCase().trim();
    }

});




taskContainer.addEventListener("click", function (event) {
    let editIcon = event.target.closest(".edit-icon");

    if (event.target.closest(".task-status-btn")) {
        console.log("Status button clicked");
        let taskRow = event.target.closest(".each-task-row");
        let taskId = +(taskRow.dataset.id);
        let selectedTask = tasks.find(task => task.id === taskId);
        selectedTask.status = selectedTask.status === "Completed" ? "Pending" : "Completed";

        window.renderSubjectChart();
        saveTasks();
        updateTaskCounts();
        window.renderSubjects();
        renderTaskStatus();
        window.dashboardSubjectProgress();
    }
});



let cBtn = document.querySelectorAll(".common-task-btn");
let all = document.querySelector(".all-task-btn");
let pend = document.querySelector(".pending-task-btn");
let com = document.querySelector(".complete-task-btn");

function allDefault(){
    search = "All";
    taskContainer.innerHTML = "";
    pend.classList.remove("colorBtn");
    com.classList.remove("colorBtn");
    all.classList.add("colorBtn");
    tasks.filter(task => task.status == "Pending").forEach(task => renderTasks(task));
    tasks.filter(task => task.status == "Completed").forEach(task => renderTasks(task));
}

allDefault();

cBtn.forEach((ele) => {
    ele.addEventListener("click", () => {
        console.log(ele.textContent);
        if (ele.textContent.trim() == "All") {
            allDefault();
        }
        else if (ele.textContent.trim() == "Pending") {
            search = "Pending";
            taskContainer.innerHTML = "";
            pend.classList.add("colorBtn");
            com.classList.remove("colorBtn");
            all.classList.remove("colorBtn");
            console.log("sdfghj", tasks);
            let pendingTasks = tasks.filter(task => task.status == "Pending");
            pendingTasks.forEach(task => renderTasks(task));
            console.log(pendingTasks)
        }
        else if (ele.textContent.trim() == "Completed") {
            search = "Completed";
            taskContainer.innerHTML = "";
            pend.classList.remove("colorBtn");
            com.classList.add("colorBtn");
            all.classList.remove("colorBtn");
            let CompletedTasks = tasks.filter(task => task.status == "Completed");
            CompletedTasks.forEach(task => renderTasks(task));
            console.log(CompletedTasks)
        }
    })
})


let searchTask = document.querySelector("#taskSearching");

searchTask.addEventListener("input", () => {
    let searchVal = searchTask.value.toLowerCase().trim();
    taskContainer.innerHTML = "";
    let inputTasks = tasks.filter(task => task.name.toLowerCase().includes(searchVal));
    inputTasks.forEach(task => renderTasks(task));
})

dashboardCount();



function renderTaskStatus() {
    taskContainer.innerHTML = "";

    if (search === "Completed") {
        let filteringTask = tasks.filter(task => task.status === "Completed");
        filteringTask.forEach(task => renderTasks(task));
    }
    else if (search === "Pending") {
        let filteringTask = tasks.filter(task => task.status === "Pending");
        filteringTask.forEach(task => renderTasks(task));
    }
    else {
        let pendings = tasks.filter(task => task.status == "Pending");
        pendings.forEach((task) => renderTasks(task));
        let completings = tasks.filter(task => task.status == "Completed");
        completings.forEach((task) => renderTasks(task));

    }

}

renderTaskStatus();
