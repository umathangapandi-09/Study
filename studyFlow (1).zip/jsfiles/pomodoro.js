let timerDisplay = document.querySelector("#timer-display");
let startBtn = document.querySelector("#timer-start");
let pauseBtn = document.querySelector("#timer-pause");
let resetBtn = document.querySelector("#timer-reset");
let modeButtons = document.querySelectorAll(".timer-modes button");
let timerSubject = document.querySelector("#timer-subject");


let selectedMinutes = 25;
let remainingSeconds = selectedMinutes * 60;
let timerInterval = null;
let isRunning = false;
let currentMode = "Focus";
let modeSelected = false;
let previewSeconds = null;

let focusTime = 25 * 60;
let shortBreak = 5 * 60;
let longBreak = 15 * 60;

let focusCompleted = false;
let focusRunning = false;
let focusInterval = null;

let elapsedSeconds = 0;
let savedSeconds = 0;


function updateTimerDisplay() {
    let displaySeconds = previewSeconds !== null ? previewSeconds : remainingSeconds;

    let minutes = Math.floor(displaySeconds / 60);
    let seconds = displaySeconds % 60;

    timerDisplay.textContent = String(minutes).padStart(2, "0") + ":" + String(seconds).padStart(2, "0");
}


function todayStudyTime() {
    let today = new Date();

    let year = today.getFullYear();
    let month = String(today.getMonth() + 1).padStart(2, "0");
    let day = String(today.getDate()).padStart(2, "0");

    let currentdate = `${year}-${month}-${day}`;

    return {
        currentdate: currentdate
    };
}


totalhours = document.querySelector(".total-hoursBY");
goalinput = document.querySelector("#studyGoal");

function updateDailyGoalProgress() {
    let todayData = todayStudyTime();
    let userId = localStorage.getItem("currentUserId")
    let users = JSON.parse(localStorage.getItem("users")) || [];

    let user = users.find(ele => +(ele.id) === +(userId));

    if (!user) {
        return
    }
    
    let studyTime = 0;

    if (user.studytime && user.studytime[todayData.currentdate]) {
        studyTime = +(user.studytime[todayData.currentdate])
    }

    let goalHours = +(localStorage.getItem("studyGoalHours")) || +(goalinput.value);

    let percentage = Math.min(100, Math.ceil((studyTime / (goalHours * 60)) * 100));

    let hours = Math.floor(studyTime / 60);
    let minutes = Math.round(studyTime % 60);

    let goalTime = document.querySelector("#dashboard-study-time");
    let studyTimeCard = document.querySelector("#dashboard-study-time-card");
    let progressFill = document.querySelector("#goal-progress-fill");
    let percentageText = document.querySelector("#goal-percentage");

    goalTime.textContent = `${hours}h ${minutes}m`;

    studyTimeCard.textContent = `${hours}h ${minutes}m`;

    progressFill.style.width = `${percentage}%`;

    percentageText.textContent = `${percentage}%`;


}



function saveStudyTime() {
    if (elapsedSeconds <= savedSeconds) {
        return;
    }

    let todayDate = todayStudyTime().currentdate;
    let userId = localStorage.getItem("currentUserId");
    let users = JSON.parse(localStorage.getItem("users")) || [];

    let user = users.find(ele => +(ele.id) === +(userId));

    if (!user) {
        return;
    }
    let newMins = (elapsedSeconds - savedSeconds) / 60;

    user.studytime[todayDate] =
        +(user.studytime[todayDate] || 0) + newMins;

    localStorage.setItem("users", JSON.stringify(users));

    savedSeconds = elapsedSeconds;

    updateDailyGoalProgress();
}

let errorMsg = document.querySelector("#error-msg");
let errorTime = null;



modeButtons.forEach((button) => {
    button.addEventListener("click", () => {
        let clickedMode = button.textContent.trim();

        modeButtons.forEach((btn) => {
            btn.classList.remove("active");
        });
        button.classList.add("active");

        if (isRunning) {
            if (clickedMode === "Focus") {
                previewSeconds = null;
                timerDisplay.textContent = String(Math.floor(remainingSeconds / 60)).padStart(2, "0") + ":" + String(remainingSeconds % 60).padStart(2, "0");
            }
            else {
                previewSeconds = +(button.dataset.minutes) * 60;
                updateTimerDisplay();
            }
            return;
        }

        previewSeconds = null;

        if (currentMode === "Focus") {
            focusTime = remainingSeconds;
        }
        else if (currentMode === "Short Break") {
            shortBreak = remainingSeconds;
        }
        else if (currentMode === "Long Break") {
            longBreak = remainingSeconds;
        }

        selectedMinutes = Number(button.dataset.minutes);
        currentMode = clickedMode;
        modeSelected = true;

        if (currentMode === "Focus") {
            remainingSeconds = focusTime;
        }
        else if (currentMode === "Short Break") {
            remainingSeconds = shortBreak;
        }
        else if (currentMode === "Long Break") {
            remainingSeconds = longBreak;
        }

        updateTimerDisplay();
    });
});



startBtn.addEventListener("click", () => {
    if (isRunning) {
        errorMsg.style.display = "block";

        clearTimeout(errorTime);

        errorTime = setTimeout(() => {
            errorMsg.style.display = "none";
        }, 3000);

        return;
    }
    if (!modeSelected) {
        alert("Select mode");
    }


    // if (currentMode === "Focus" && !timerSubject.value) {
    //     alert("Select subject");
    //     return;
    // }

    if (currentMode === "Focus" && !focusRunning) {
        focusRunning = true;

        focusInterval = setInterval(() => {
            if (focusTime > 0) {
                focusTime--;
                elapsedSeconds++;
                if (currentMode === "Focus") {
                    remainingSeconds = focusTime;
                    updateTimerDisplay();
                }
            }

            if (focusTime <= 0) {
                clearInterval(focusInterval);
                focusInterval = null;
                focusRunning = false;
                focusCompleted = true;
                saveStudyTime();
                elapsedSeconds = 0;
                savedSeconds = 0;
                isRunning = false;
                startBtn.classList.remove("active");
            }
        }, 1000);
    }

    isRunning = true;
    startBtn.classList.add("active");
    pauseBtn.classList.remove("active");

    if (currentMode !== "Focus") {
        timerInterval = setInterval(() => {
            if (remainingSeconds > 0) {
                remainingSeconds--;
                updateTimerDisplay();
            } else {
                clearInterval(timerInterval);
                timerInterval = null;
                isRunning = false;
                startBtn.classList.remove("active");
            }
        }, 1000);
    }
});



pauseBtn.addEventListener("click", () => {
    if (pauseBtn.textContent === "Resume") {

        isRunning = false;
        pauseBtn.textContent = "Pause";

        startBtn.click();

        return;
    }
    if (currentMode === "Focus" && focusRunning) {
        clearInterval(focusInterval);
        focusInterval = null;
        focusRunning = false;
        saveStudyTime();
    }

    if (timerInterval) {
        clearInterval(timerInterval);
        timerInterval = null;
    }

    isRunning = false;

    pauseBtn.classList.add("active");
    startBtn.classList.remove("active");
    pauseBtn.textContent = "Resume";
});

resetBtn.addEventListener("click", () => {
    clearInterval(timerInterval);
    clearInterval(focusInterval);

    timerInterval = null;
    focusInterval = null;

    isRunning = false;
    focusRunning = false;

    startBtn.classList.remove("active");
    pauseBtn.classList.remove("active");
    pauseBtn.textContent = "Pause";

    if (currentMode === "Focus") {
        saveStudyTime();
        focusTime = 25 * 60;
        remainingSeconds = focusTime;
    }
    else if (currentMode === "Short Break") {
        shortBreak = 5 * 60;
        remainingSeconds = shortBreak;
    }
    else if (currentMode === "Long Break") {
        longBreak = 15 * 60;
        remainingSeconds = longBreak;
    }

    updateTimerDisplay();
});

updateDailyGoalProgress();


console.log(localStorage.getItem("studyTime"))