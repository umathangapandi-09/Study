let taskNav = document.querySelector("#taskNav");
let dashNav = document.querySelector("#dashNav");
let subNav = document.querySelector("#subNav");
let taskPage = document.querySelector("#task-page");
let pageContent = document.querySelector("#dashboard-page");
let subPage = document.querySelector("#subject-page");
let timerNav = document.querySelector("#timerNav");
let timerPage = document.querySelector("#pomodoro-page");

let header = document.querySelector("#main-header");
let welcomeSection = document.querySelector(".welcome-section");

let hiClear = document.querySelector("#hii-clear");
let username = document.querySelector(".username");
let clearp = document.querySelector("#clear-p");
let originalUsername = username.textContent;
let hiding = document.querySelector(".hiding");

taskNav.closest("a").addEventListener("click", (e) => {
    e.preventDefault();
    pageContent.style.display = "none";
    welcomeSection.style.display = "none";
    hiding.style.display = "block";
    headChange.textContent = "My Tasks 📊"
    taskPage.style.display = "block";
    timerPage.style.display = "none";
    subPage.style.display = "none";
    setActiveNav(taskNav);
});

dashNav.closest("a").addEventListener("click", (e) => {
    e.preventDefault();
    taskPage.style.display = "none";
    welcomeSection.style.display = "block";
    hiding.style.display = "none";
    timerPage.style.display = "none";
    pageContent.style.display = "block";
    subPage.style.display = "none";
    console.log(dashNav);
    console.log(dashNav.closest("a"));
    setActiveNav(dashNav);
});

let headChange = document.querySelector(".hiding h1");

subNav.closest("a").addEventListener("click", (e) => {
    e.preventDefault();
    taskPage.style.display = "none";
    welcomeSection.style.display = "none";
    pageContent.style.display = "none";
    subPage.style.display = "block";
    timerPage.style.display = "none";
    hiding.style.display = "block";
    headChange.textContent = "Subjects 📚"
    setActiveNav(subNav);
})


timerNav.closest("a").addEventListener("click", (e) => {
    e.preventDefault();
    pageContent.style.display = "none";
    taskPage.style.display = "none";
    subPage.style.display = "none";

    welcomeSection.style.display = "none";
    hiding.style.display = "block";
    headChange.textContent = "Pomodoro Timer 🍅";

    timerPage.style.display = "block";
    setActiveNav(timerNav);
});

function setActiveNav(activeNav) {
    let sideAnchor = document.querySelectorAll(".side-bar a")
    sideAnchor.forEach((link) => {
        link.classList.remove("active");
    });

    let target = activeNav.closest("a");
    console.log("taget",target)
    if (target){
        target.classList.add("active");
    }    
}

function showDashboardPage() {
    taskPage.style.display = "none";
    subPage.style.display = "none";
    timerPage.style.display = "none";

    pageContent.style.display = "block";
    welcomeSection.style.display = "block";
    hiding.style.display = "none";

    setActiveNav(dashNav);
}

let comingFirst = document.querySelector("#come-to-first");

comingFirst.addEventListener("click", () => {
    taskPage.style.display = "none";
    welcomeSection.style.display = "block";
    hiding.style.display = "none";
    timerPage.style.display = "none";
    pageContent.style.display = "block";
    subPage.style.display = "none";
    setActiveNav(dashNav);
})

let gotask = document.querySelector("#goto-task");

gotask.addEventListener("click", () => {
    pageContent.style.display = "none";
    welcomeSection.style.display = "none";
    hiding.style.display = "block";
    headChange.textContent = "My Tasks 📊"
    taskPage.style.display = "block";
    timerPage.style.display = "none";
    subPage.style.display = "none";
    setActiveNav(taskNav);
})


let gosub = document.querySelector("#goto-sub");

gosub.addEventListener("click", () => {
    taskPage.style.display = "none";
    welcomeSection.style.display = "none";
    pageContent.style.display = "none";
    subPage.style.display = "block";
    timerPage.style.display = "none";
    hiding.style.display = "block";
    headChange.textContent = "Subjects 📚"
    setActiveNav(subNav);
})


let timeRedirect = document.querySelector("#time-redirect");
let taskRedirect = document.querySelector("#task-redirect");
let subRedirect = document.querySelector("#sub-redirect");


taskRedirect.addEventListener("click", (e) => {
    e.preventDefault();
    pageContent.style.display = "none";
    welcomeSection.style.display = "none";
    hiding.style.display = "block";
    headChange.textContent = "My Tasks 📊"
    taskPage.style.display = "block";
    timerPage.style.display = "none";
    subPage.style.display = "none";
    setActiveNav(taskNav);
});

subRedirect.addEventListener("click", (e) => {
    e.preventDefault();
    taskPage.style.display = "none";
    welcomeSection.style.display = "none";
    pageContent.style.display = "none";
    subPage.style.display = "block";
    timerPage.style.display = "none";
    hiding.style.display = "block";
    headChange.textContent = "Subjects 📚"
    setActiveNav(subNav);
})


timeRedirect.addEventListener("click", (e) => {
    e.preventDefault();
    pageContent.style.display = "none";
    taskPage.style.display = "none";
    subPage.style.display = "none";

    welcomeSection.style.display = "none";
    hiding.style.display = "block";
    headChange.textContent = "Pomodoro Timer 🍅";

    timerPage.style.display = "block";
    setActiveNav(timerNav);
});



















