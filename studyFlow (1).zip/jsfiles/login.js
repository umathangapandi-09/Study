
let loginMain = document.querySelector(".login-main");

let side = document.querySelector(".side-bar");

let dash = document.querySelector(".main-dashboard");

let loginPage = document.querySelector(".user-login-page");

let loginForm = document.querySelector(".user-login-form1");
let mailInput = document.querySelector("#mail-id");
let passInput = document.querySelector("#pass");
let heading = document.querySelector(".welcome-form h1");
let loginBtn = document.querySelector(".login-main");


let users = JSON.parse(localStorage.getItem("users")) || [];
let isLoggedIn = (localStorage.getItem("isLoggedIn") === "true");

localStorage.setItem("users", JSON.stringify(users));

let nameInput = document.querySelector("#name");

let nameGroup = document.querySelector(".name-grp");

let isSignUp = false;

let switchUpIn = document.querySelector("#toggleMode");
let nameField = document.querySelector(".name-field");
let nameLabel = document.querySelector(".name-label");
let mailicon = document.querySelector("#mailing")
let lockicon = document.querySelector("#locking")
nameLabel.style.display = "none";
nameField.style.display = "none";
nameInput.required = false;

switchUpIn.addEventListener("click", (event) => {
    event.preventDefault();

    if (isSignUp == true) {
        isSignUp = false;
    }
    else {
        isSignUp = true;
    }

    if (isSignUp) {
        heading.textContent = "Create your account";
        loginBtn.textContent = "Sign Up →";
        nameField.style.display = "block";
        nameLabel.style.display = "block";
        nameInput.required = true;
        switchUpIn.textContent = "Already have an account? Sign in";
    }
    else {
        heading.textContent = "Sign in to your account";
        loginBtn.textContent = "Login →";
        nameLabel.style.display = "none";
        nameField.style.display = "none";
        nameInput.required = false;
        switchUpIn.textContent = "Don't have an account? Sign up";
    }
});


function isStrong(pwd) {
    let regex = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[^A-Za-z0-9\s])(?=\S{8,}$).*$/;
    return regex.test(pwd);
}

async function sha256Hex(message) {
    const bytes = new TextEncoder().encode(message);
    const hash = await crypto.subtle.digest("SHA-256", bytes);
    return Array.from(new Uint8Array(hash), b => b.toString(16).padStart(2, "0")).join("");
}

function loadUser(){

    let userId = localStorage.getItem("currentUserId");
    let latestUsers = JSON.parse(localStorage.getItem("users")) || [];
    let user = latestUsers.find(ele => ele.id == userId);

    if (!user){
        return;
    }

    let username = document.querySelector(".username");
    let innerName = document.querySelector(".info p");
    let innerMail = document.querySelector(".inner-mail");

    username.textContent = user.name;
    innerName.textContent = user.name;
    innerMail.textContent = user.email;
    window.loadTasksForCurrentUser();
    window.loadSubjectsForCurrentUser();
    dashboardSubjectProgress();
}


function showWelcomeThenDashboard() {
    let welcome = document.querySelector("#welcome-screen");
    let loginPage = document.querySelector(".user-login-page");
    let dashboard = document.querySelector(".main-dashboard");

    loginPage.style.display = "none";
    dashboard.style.display = "none";

    welcome.style.display = "flex";
    setTimeout(() => {
        welcome.style.display = "none";
        showDashboardPage();
        dashboard.style.display = "block";
        side.style.display = "block";
    }, 2000);
}

loginForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    
    let users = JSON.parse(localStorage.getItem("users")) || [];

    let mailVal = mailInput.value.trim().toLowerCase();
    let passVal = passInput.value;
    let passHash = await sha256Hex(passVal);
    let nameVal = nameInput.value.trim();
    let innerName = document.querySelector(".info p");
    let innerMail = document.querySelector(".inner-mail");

    if (isSignUp) {

        let existingUser = users.find((user) => {
            return user.email === mailVal;
        });

        if (existingUser) {
            alert("This email is already registered");
            return;
        }
        if (!isStrong(passVal)) {
            alert("Weak password");
            return
        }

        let newUser = {
            id: Date.now(),
            name: nameVal,
            email: mailVal,
            password: passHash,
            goal: 4,
            subjects: [],
            tasks: [],
            studytime : {}
        };

        users.push(newUser);
        localStorage.setItem("users", JSON.stringify(users));
        isSignUp = false;
        heading.textContent = "Sign in to your account";
        console.log("Existing User", existingUser)
        innerName.textContent = newUser.name;
        innerMail.textContent = newUser.email;
        loginBtn.textContent = "Login →";
        nameGroup.style.display = "none";
        nameLabel.style.display = "none";
        nameInput.required = false;
        switchUpIn.textContent = "Don't you have an account? Sign up";
        loginForm.reset();
    }
    else {
        let user = users.find((user) => {
            return user.email === mailVal;
        });

        if (!user) {
            alert("Account not found. Please sign up first.");
            return;
        }

        if (user.password !== passHash) {
            alert("Incorrect password");
            return;
        }

        isLoggedIn = true;
        localStorage.setItem("isLoggedIn",isLoggedIn);
        localStorage.setItem("currentUserId",user.id);
        loadUser();
        showWelcomeThenDashboard();
    }
    loginForm.reset();
});


if (isLoggedIn){
    let userId = localStorage.getItem("currentUserId");
    let latestUsers = JSON.parse(localStorage.getItem("users")) || [];
    let user = latestUsers.find(ele => ele.id == userId);
    
    if (user) {
        loadUser();
        side.style.display = "block";
        dash.style.display = "block";
        loginPage.style.display = "none";
    }
    else{
        isLoggedIn = false;
        localStorage.setItem("isLoggedIn", isLoggedIn);
        localStorage.removeItem("currentUserId");
    }
}


