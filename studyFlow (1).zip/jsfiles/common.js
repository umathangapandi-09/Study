let profile = document.querySelectorAll(".user-profile-icon");
let userPage = document.querySelector(".user-page-popup");
let closeUser = document.querySelector(".cross-close");
let editSetting = document.querySelector(".edit-profile");
let dummyDiv = document.querySelector(".dummy");
let overlay = document.querySelector(".overlay-edit");
let closeSetting = document.querySelector(".close-in-profile");

let detailBtn = document.querySelector(".details-btn");


let date = document.querySelector("#dateDisplay");

flatpickr(date, {
    defaultDate: new Date(),
    dateFormat: "d M Y"
});


profile.forEach(icon => {
    icon.addEventListener("click", () => {
        userPage.style.display = "flex";
        dummyDiv.style.display = "block";
    });
});

closeUser.addEventListener("click", () => {
    dummyDiv.style.display = "none";
    userPage.style.display = "none";
});

dummyDiv.addEventListener("click",(e)=>{
    if(!e.target.closest(".user-page-popup")){
        dummyDiv.style.display="none";
    }
})

editSetting.addEventListener("click", () => {
    let currentUserId = localStorage.getItem("currentUserId");
    
    let users = JSON.parse(localStorage.getItem("users")) || [];

    let user = users.find(ele => {
        return +(ele.id) === +(currentUserId);
    })
    overlay.style.display = "block";
    profileName.value = user.name;
    profileMail.value = user.email;
    goalTime.value = user.goal;


});

closeSetting.addEventListener("click", () => {
    overlay.style.display = "none";
});


let profileForm = document.querySelector(".profile-form");
let profileName = document.querySelector("#profileName");
let profileMail = document.querySelector("#profileEmail");

let goalTime = document.querySelector("#studyGoal");


profileForm.addEventListener("submit",(e) => {
    e.preventDefault();
    overlay.style.display = "none";
    let nameVal = profileName.value.trim();
    let mailVal = profileMail.value.toLowerCase().trim();
    let goal = +(goalTime.value);

    let currentUserId = localStorage.getItem("currentUserId");
    
    let users = JSON.parse(localStorage.getItem("users")) || [];

    let user = users.find(ele => {
        return ele.id == currentUserId;
    })

    if (!user){
        return alert("No user found");
    }

    user.name = nameVal;
    user.email = mailVal
    user.goal = goal

    localStorage.setItem("users", JSON.stringify(users));

    let innerName = document.querySelector(".info p");
    let innerMail = document.querySelector(".inner-mail");

    innerMail.textContent = user.email;
    innerName.textContent = user.name;

})

let logout = document.querySelector(".logout")

logout.addEventListener("click",() => {
    side.style.display = "none";
    dash.style.display = "none";
    loginPage.style.display = "flex";
    dummyDiv.style.display = "none";
    isLoggedIn = false;
    localStorage.setItem("isLoggedIn", isLoggedIn);
    localStorage.removeItem("currentUserId");
})

let goalForm = document.querySelector(".goal-form");
let overlayGoal = document.querySelector(".overlay-goal");
let cb = document.querySelector("#cb");

let totalhours = document.querySelector(".total-hoursBY");
let setGoalSubmit = document.querySelector(".setGoalBtn");
let goalinput = document.querySelector("#studyGoal");
let userId = localStorage.getItem("currentUserId");

users = JSON.parse(localStorage.getItem("users")) || [];

user = users.find(ele => ele.id == userId);

if (user){
    let goalSet = user.goal;

    goalinput.value = goalSet;
    totalhours.textContent = ` /${goalinput.value}h`;
}
    


goalForm.addEventListener("submit",(e) => {
    e.preventDefault();
    let userId = localStorage.getItem("currentUserId");

    let users = JSON.parse(localStorage.getItem("users")) || [];

    let user = users.find(ele => ele.id == userId);
    
    user.goal = +(goalinput.value);
    
    let goalSet = user.goal;

    localStorage.setItem("users",JSON.stringify(users));

    goalinput.value = goalSet;
    totalhours.textContent = ` /${goalinput.value}h`;
    goalForm.style.display = "none";
    overlayGoal.style.display = "none";
})

detailBtn.addEventListener("click", () => {
    console.log("Goal form clicked")
    goalForm.style.display = "block";
    overlayGoal.style.display = "block";
});


cb.addEventListener("click",() => {
    goalForm.style.display = "none";
    overlayGoal.style.display = "none";
})















